<?php 
$koneksi = mysqli_connect("localhost","linda","smkn3tbn","digitalibrary");
 
// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}
 
?>