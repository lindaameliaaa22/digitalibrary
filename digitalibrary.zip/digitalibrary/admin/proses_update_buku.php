<?php 
// koneksi database
include '../koneksi.php';
 
// menangkap data yang di kirim dari form
$BukuID = $_POST['BukuID'];
$Judul = $_POST['Judul'];
$Penulis = $_POST['Penulis'];
$Penerbit = $_POST['Penerbit'];
$TahunTerbit = $_POST['TahunTerbit'];
$Stok = $_POST['Stok'];
 
// menginput data ke database
mysqli_query($koneksi,"update buku set Judul='$Judul', Penulis='$Penulis', Penerbit='$Penerbit', TahunTerbit='$TahunTerbit', Stok='$Stok' where BukuID='$BukuID'");
 
// mengalihkan halaman kembali ke buku.php
header("location:buku.php?pesan=update");
 
?>